CREATE PROC SendCurseNotification
		@accountID int,
	@text nvarchar(200)
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Notification nvarchar(100);
	SET @Notification = 'ADMIN MESSAGE!' + @text;
	INSERT INTO dbo.[NOTIFICATION]
		(
			TEXT,
			ACCOUNT_ID
		)
	VALUES
		(
			@Notification,
			@accountID
		)
		
END;