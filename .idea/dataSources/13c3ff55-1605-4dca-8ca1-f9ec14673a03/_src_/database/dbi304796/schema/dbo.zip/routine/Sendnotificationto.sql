CREATE PROC [dbo].[Sendnotificationto]
	@accountID int,
	@friendID int,
	@link nvarchar(200)
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @accountName nvarchar(50);
	DECLARE @Notification nvarchar(100);
	SET @accountName = (SELECT A.NAME FROM ACCOUNT A WHERE A.ID = @accountID)
	SET @Notification = @accountName + ' uploaded a new video! LINK: ' + @link
	INSERT INTO dbo.[NOTIFICATION]
		(
			TEXT,
			ACCOUNT_ID
		)
	VALUES
		(
			@Notification,
			@friendID
		)
		
END;