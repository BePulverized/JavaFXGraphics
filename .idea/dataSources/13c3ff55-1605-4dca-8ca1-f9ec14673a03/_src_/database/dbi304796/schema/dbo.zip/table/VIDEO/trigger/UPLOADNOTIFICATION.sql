
CREATE TRIGGER [dbo].[UPLOADNOTIFICATION]
ON [dbo].[VIDEO]
AFTER INSERT

AS

-- define the last customer ID handled

-- define the customer ID to be handled now
DECLARE @MyCursor CURSOR;
DECLARE @Myfield INT;
DECLARE @ACCOUNTID INT;
DECLARE @COUNTER INT;
DECLARE @LINK NVARCHAR(200)
SET @COUNTER = 0;
SELECT @ACCOUNTID=ACCOUNT_ID FROM INSERTED
SELECT @LINK=LINK FROM INSERTED
SET @MyCursor = CURSOR FOR
select f.friend_id from friend f where f.account_id = @ACCOUNTID
-- select the next customer to handle    
OPEN @MyCursor
FETCH NEXT FROM @MyCursor
INTO @Myfield
PRINT 'CURSOR DECLARED'
-- as long as we have customers......    
WHILE @@FETCH_STATUS = 0
BEGIN
SET @COUNTER =  @COUNTER + 1;
	PRINT @COUNTER;
    -- call your sproc
	Exec Sendnotificationto @accountID=@ACCOUNTID , @friendid = @Myfield, @link=@LINK
	PRINT 'SUCCESFULL PROCEDURE'
    -- set the last customer handled to the one we just handled
    FETCH NEXT FROM @MyCursor
	INTO @Myfield

    -- select the next customer to handle    
    
END;