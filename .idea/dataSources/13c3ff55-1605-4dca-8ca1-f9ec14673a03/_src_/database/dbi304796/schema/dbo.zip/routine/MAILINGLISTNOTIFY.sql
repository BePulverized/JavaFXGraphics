CREATE PROC [dbo].[MAILINGLISTNOTIFY]
@TEXTnote NVARCHAR(200)
AS
 
DECLARE @Myfield INT
DECLARE @MYCURSOR CURSOR;
SET @MyCursor = CURSOR FOR
SELECT M.ACCOUNT_ID FROM MAILINGLIST M
open @MyCursor

FETCH NEXT FROM @MyCursor
INTO @Myfield
PRINT 'CURSOR DECLARED'

-- as long as we have customers......    
WHILE @@FETCH_STATUS = 0
BEGIN
    -- call your sproc
	exec SendCursenotification @accountID = @Myfield, @text = @TEXTnote
	PRINT @Myfield
	PRINT '1'
    -- set the last customer handled to the one we just handled
    FETCH NEXT FROM @MyCursor
	INTO @Myfield

    -- select the next customer to handle    
    
END;