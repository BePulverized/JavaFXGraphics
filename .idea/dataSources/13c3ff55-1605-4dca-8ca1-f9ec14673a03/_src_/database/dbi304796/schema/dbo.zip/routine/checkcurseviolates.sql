CREATE proc [dbo].[checkcurseviolates] 
@MESSAGECOUNT INT
as

declare @MyCursor CURSOR;
DECLARE @MyField INT;
SET @MyCursor = CURSOR FOR
SELECT A.ID FROM ACCOUNT A INNER JOIN REACTION R ON R.ACCOUNT_ID = A.ID WHERE R.TEXT LIKE '%*%' GROUP BY A.ID HAVING COUNT(R.TEXT) >= @MESSAGECOUNT

open @MyCursor

FETCH NEXT FROM @MyCursor
INTO @Myfield
PRINT 'CURSOR DECLARED'
TRUNCATE TABLE MAILINGLIST
-- as long as we have customers......    
WHILE @@FETCH_STATUS = 0
BEGIN
    -- call your sproc
	if not exists(select * from mailinglist m where m.account_Id = @MyField)
	insert into mailingList(account_id) values(@MyField)
	PRINT 'SUCCESFULL PROCEDURE'
    -- set the last customer handled to the one we just handled
    FETCH NEXT FROM @MyCursor
	INTO @Myfield

    -- select the next customer to handle    
    
END;